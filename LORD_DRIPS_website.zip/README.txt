# LORD DRIPS™ Website

Open `index.html` in a browser to preview the site.

Before publishing:
1. Replace the WhatsApp link in `index.html` with your real WhatsApp number in international format.
2. Replace `your@email.com` with your business email.
3. Replace the Instagram link with your real Instagram profile.
4. Replace the sample product prices/details with your real products.
5. Add your own product/logo photos if you want them.

This is a static website (HTML/CSS/JavaScript), so it can be hosted on services such as GitHub Pages, Netlify, or Vercel.
